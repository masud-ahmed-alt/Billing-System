<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Latitud / Longitud",
    "DESC" => "Este tipo de dato genera una longitud y/o latitud aleatoria. Si se eligen ambas, mostrará ambas separadas por una coma."
);

$L["latitude"] = "Latitud";
$L["longitude"] = "Longitud";
