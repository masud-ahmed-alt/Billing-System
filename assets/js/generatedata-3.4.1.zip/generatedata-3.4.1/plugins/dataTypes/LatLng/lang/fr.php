<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Lat/Lng",
    "DESC" => "Ce type de données génère une latitude et / ou une longitude aléatoire. Si les deux sont sélectionnés, il les affiche séparés par une virgule."
);

$L["latitude"] = "Latitude";
$L["longitude"] = "Longitude";
