<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Breedtegraad / Lengtegraad",
    "DESC" => "Dit gegevenstype genereert een willekeurige lengte- en/of breedtegraad. Indien beide zijn geselecteerd worden beide weergegeven gescheiden door een komma."
);

$L["latitude"] = "Breedtegraad";
$L["longitude"] = "Lengtegraad";
