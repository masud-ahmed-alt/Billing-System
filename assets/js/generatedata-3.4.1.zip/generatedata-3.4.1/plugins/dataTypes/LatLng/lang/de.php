<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Breite / Länge",
    "DESC" => "Dieser Datentyp generiert einen zufälligen Breite und / oder Länge. Wenn beide ausgewählt sind, zeigt er sowohl durch ein Komma getrennt."
);

$L["latitude"] = "Breite";
$L["longitude"] = "Länge";
