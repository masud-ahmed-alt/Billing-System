<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Burgerservicenummer",
    "DESC" => "Genereert een willekeurige Amerikaanse sofi-nummer."
);

$L["help_1"] = "De gegenereerde IBAN heeft een geldige controlesom, landcode en lengte en de BIC staat op de juiste plaats.";
$L["help_2"] = "Het is echter zeer onwaarschijnlijk dat het aantal echt <i>geldig</i> is, omdat er meestal een aantal controles zijn die landspecifiek zijn.";
