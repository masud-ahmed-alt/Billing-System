<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Social Security Number (SSN)",
    "DESC" => "Generates a random US social security number."
);
