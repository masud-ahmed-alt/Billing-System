<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Burgerservicenummer",
    "DESC" => "Genereert een willekeurige Amerikaanse sofi-nummer."
);
