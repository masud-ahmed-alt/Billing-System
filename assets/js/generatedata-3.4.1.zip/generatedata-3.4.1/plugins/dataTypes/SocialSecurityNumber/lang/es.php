<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Número de seguridad social",
    "DESC" => "Genera un número aleatorio de seguridad social de Estados Unidos."
);
