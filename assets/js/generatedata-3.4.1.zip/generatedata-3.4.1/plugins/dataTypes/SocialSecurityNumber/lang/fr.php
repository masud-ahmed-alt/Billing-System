<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Numéro de sécurité sociale",
    "DESC" => "Génère un numéro de sécurité sociale aléatoire des États-Unis."
);
