<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Sozialversicherungsnummer",
    "DESC" => "Erzeugt eine zufällige Sozialversicherungsnummer USA."
);
