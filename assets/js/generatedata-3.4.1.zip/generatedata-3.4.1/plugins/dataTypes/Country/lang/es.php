<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "País",
    "DESC" => "Genera un nombre de país al azar , con la opción de limitar el subconjunto de esos países entraron a través de la interfaz."
);

$L["limit_results"] = "Limitar los países a los elegidos más arriba";
