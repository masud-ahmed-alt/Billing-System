<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Land",
    "DESC" => "Genereert een willekeurige landnaam, met de optie om de subset te beperken tot die landen die zijn opgegeven via de interface."
);

$L["limit_results"] = "Beperk landen met de hierboven opgegeven";
