<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Alfanumérico",
    "DESC" => "Genera una cadena alfanumérica personalizada azar o cualquier longitud o formato, definida por caracteres de marcador de posición ."
);

$L["example_CanPostalCode"] = "(Código postal canadiense)";
$L["example_Password"] = "(Contraseña)";
$L["example_USZipCode"] = "(Código postal yankee)";
$L["help_1"] = "Una <b>L</b>etra mayúscula.";
$L["help_10"] = "Cualquier número, 1-9.";
$L["help_11"] = "Una constante (mayúscula o minúscula).";
$L["help_12"] = "Un número <b>H</b>exadecimal (0-F)";
$L["help_2"] = "Una <b>V</b>ocal mayúscula.";
$L["help_3"] = "Una <b>l</b>etra minúscula.";
$L["help_4"] = "Una <b>v</b>ocal minúscula.";
$L["help_5"] = "Una letra (mayúscula o minúscula).";
$L["help_6"] = "Una vocal (mayúscula o minúscula).";
$L["help_7"] = "Una <b>C</b>onstante mayúscula.";
$L["help_8"] = "Cualquier número, 0-9.";
$L["help_9"] = "Una <b>c</b>onstante minúscula.";
$L["help_intro"] = "Estos tipos de datos te permiten generar cadenas alfanuméricas aleatorias. La siguiente tabla contiene la leyenda para este campo. Cualquier otro carácter que introduzcas en este campo aparecerá sin escapar.";
$L["incomplete_fields"] = "Los campos alfanuméricos requieren que se introduzca el formato en el campo de texto Opciones. Por favor, corrija las siguientes filas:";
