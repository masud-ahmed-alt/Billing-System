<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PAN",
    "DESC" => "Este tipo de datos genera números, tarjeta de crédito válida al azar de acuerdo con el formato que se especifique."
);

$L["pan_incomplete_fields"] = "Por lo menos una marca de la tarjeta debe ser seleccionado. Por favor, corrija los siguientes filas:";
$L["separator_help"] = "Los caracteres que introduzca aquí se utilizarán para reemplazar los espacios en el campo de formato de tarjeta de crédito a continuación. Para introducir más de un separador, simplemente separarlos con una barra vertical (|) carácter.";
$L["format_incomplete_fields"] = "Por campo PAN Formatos de número CC, entrada <b>X</b> de y para los separadores de entrada <b>espacios</b> de acuerdo a la longitud de la tarjeta. Por favor, corrija los siguientes filas:";
$L["pan_help_intro"] = "Actualmente es capaz de generar los números de las siguientes marcas: ";
$L["mastercard"] = "Mastercard";
$L["visa_electron"] = "Visa Electron";
$L["visa"] = "Visa";
$L["americanexpress"] = "American Express";
$L["discover"] = "Discover";
$L["american_diners"] = "American Diner's";
$L["carte_blanche"] = "Carte Blanche";
$L["diners_club_international"] = "Diner's Club International";
$L["enroute"] = "enRoute";
$L["jcb"] = "JCB";
$L["maestro"] = "Maestro";
$L["solo"] = "Solo";
$L["switch"] = "Switch";
$L["laser"] = "Laser";
$L["rand_card"] = "Tarjeta de crédito aleatorio";
$L["ccrandom"] = "Seleccione Tarjeta Marca:";
$L["format_title"] = "Si la longitud de X no es igual a la longitud de la tarjeta, entonces ese formato no conseguirá generado.";
$L["rand_brand_title"] = "Longitud de la tarjeta del marca seleccionada y el formato son recogidos al azar.";
$L["length"] = "Largo:";
$L["separators"] = "Separadores:";
$L["ccformats"] = "Formatos de Tarjeta de Crédito:";
