<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Phone / Fax, Regional",
    "DESC" => "Generates a phone number in an appropriate format for the row of data. If it encounters an unfamiliar country, it generates a default phone number in the format (xxx) xxx-xxxx."
);
