<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Telefoon / Faxnummer, Regionaal",
    "DESC" => "Dit Gegevenstype probeert een telefoonnummer in een geschikt formaat voor de rij met gegevens te genereren. Komt hij een onbekend land tegen dan gebruikt hij een standaard telefoonnummer in het formaat (xxx) xxx-xxxx."
);
