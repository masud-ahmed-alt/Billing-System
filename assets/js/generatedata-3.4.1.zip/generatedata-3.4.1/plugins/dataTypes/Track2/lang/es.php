<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 2",
    "DESC" => "Track 2 contiene la cuenta del titular de la tarjeta, PIN cifrado, además de otros datos discrecionales. La tarjeta de crédito puede ser de cualquier tipo (Visa, Mastercard, etc)."
);
