<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Chilean RUT number",
    "DESC" => "Erzeugt eine RUT / RUN- chilenischen nationalen Identifikationsnummer ."
);

$L["different_formats"] = "verschiedene Formate";
$L["incomplete_fields"] = "Die Rut Datentyp haben muss das Beispiel Feld ausgewählt . Bitte korrigieren Sie die folgenden Zeilen :";
$L["rut_default"] = "Standard";
$L["only_number"] = "nur Nummer";
$L["only_digit"] = "Nur Prüfziffer";

$L["thousands_separator"] = "Tausender-Trennzeichen";
$L["digit_uppercase"] = "Großstelligen";
$L["remove_dash"] = "ausschließen dash";
