<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Numéro de RUT chilienne",
    "DESC" => "Génère une ornière / RUN chilienne numéro national d'identification ."
);

$L["different_formats"] = "Différents formats";
$L["incomplete_fields"] = "Le type de données de Rut a besoin d'avoir le champ exemple choisi . S'il vous plaît fixer les lignes suivantes :";
$L["rut_default"] = "Défaut";
$L["only_number"] = "numéro seulement";
$L["only_digit"] = "Seulement chiffres de vérification";

$L["thousands_separator"] = "Séparateur de milliers";
$L["digit_uppercase"] = "chiffres majuscules";
$L["remove_dash"] = "exclure tableau de bord";
