<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Chileens RUT/RUN nummer",
    "DESC" => "Genereert een Chileens RUT/RUN Nationaal Identificatie Nummer ."
);

$L["different_formats"] = "Verschillende formaten";
$L["incomplete_fields"] = "Bij dit type veld moet u een voorbeeld in het optieveld invoeren. Pas de volgende rij(en) aan:";
$L["rut_default"] = "Standaard";
$L["only_number"] = "Aleen nummer";
$L["only_digit"] = "Alleen verificatie cijfers";

$L["thousands_separator"] = "duizend separator";
$L["digit_uppercase"] = "hoofdletter cijferis";
$L["remove_dash"] = "Geen dash symbool";
