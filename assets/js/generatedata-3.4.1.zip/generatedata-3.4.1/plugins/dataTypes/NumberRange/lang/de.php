<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Number Range",
    "DESC" => "Diese zufällig generiert eine Zahl zwischen den Werten, die Sie angeben. Beide Felder können Sie negative Werte eingeben."
);

$L["and"] = "und";
$L["between"] = "Zwischen";
$L["incomplete_fields"] = "Bitte geben Sie den Zahlenbereich (niedrigster und höchster Zahlen) für die folgenden Zeilen:";
