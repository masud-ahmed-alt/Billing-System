<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Nummer Range",
    "DESC" => "Dit genereert een willekeurig getal tussen de waarden die u opgeeft. In beide velden kunt u een negatieve waarde invoeren."
);

$L["and"] = "en";
$L["between"] = "Tussen";
$L["incomplete_fields"] = "Vul het nummerbereik (laagste en hoogste waarden) in voor de volgende rij(en0:";
