<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Stad",
    "DESC" => "Geeft een willekeurige stad , of indien de gegevens beschikbaar zijn , wordt een stad in het juiste land en/of regio gekozen."
);