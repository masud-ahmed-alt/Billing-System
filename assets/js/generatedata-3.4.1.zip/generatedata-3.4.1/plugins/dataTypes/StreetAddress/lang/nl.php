<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Straatnamen",
    "DESC" => "Genereert willekeurige adressen."
);

$L["ap_num"] = "Appartement #";
$L["po_box"] = "Postbus";
$L["street_types"] = "Street, St., Straat, Weg, Road, Rd., Ave, Av., Avenue";
