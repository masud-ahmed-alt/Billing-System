<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Dirección",
    "DESC" => "Genera direcciones de calles al azar ."
);

$L["ap_num"] = "Apdo.:";
$L["po_box"] = "Apartado núm.:";
$L["street_types"] = "C/,C.,Calle,Carretera,Ctra.,,Av.,Avda.,Avenida";
