<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Street Address",
    "DESC" => "Generates random street addresses."
);

$L["ap_num"] = "Ap #";
$L["po_box"] = "P.O. Box";
$L["street_types"] = "St.,St.,Street,Road,Rd.,Rd.,Ave,Av.,Avenue";
