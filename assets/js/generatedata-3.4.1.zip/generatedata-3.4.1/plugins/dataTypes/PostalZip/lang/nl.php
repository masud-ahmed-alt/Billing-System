<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Postcode",
    "DESC" => "Genereert een willekeurige postcode. Voor meer controle gebruikt u de alpha-numerieke gegevenstype optie."
);
