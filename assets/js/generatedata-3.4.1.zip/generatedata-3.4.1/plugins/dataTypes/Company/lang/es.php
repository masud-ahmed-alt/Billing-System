<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Empresa",
    "DESC" => "Este tipo de dato genera un nombre de empresa al azar, generado a partir de una palabra lorem ipsum y de un sufijo apropiado como Dolor Inc., o Convallis Limited."
);
