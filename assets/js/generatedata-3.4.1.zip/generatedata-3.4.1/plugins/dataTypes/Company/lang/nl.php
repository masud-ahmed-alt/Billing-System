<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Bedrijfsnaam",
    "DESC" => "Dit gegevenstype genereert een willekeurige bedrijfsnaam, bestaande uit een Lorem ipsum woord en een passend achtervoegsel, zoals bijvoorbeeld Dolor Inc, of Convallis Limited."
);
