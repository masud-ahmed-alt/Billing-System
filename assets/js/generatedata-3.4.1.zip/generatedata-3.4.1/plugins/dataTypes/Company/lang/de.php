<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Firma",
    "DESC" => "Dieser Datentyp generiert einen zufälligen Name des Unternehmens, einer Lorem ipsum Wort besteht und eine entsprechende Suffix, wie Dolor Inc., oder Convallis Begrenzte."
);
