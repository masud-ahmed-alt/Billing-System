<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Willekeurig Aantal Woorden",
    "DESC" => "Deze optie genereert een willekeurig aantal woorden - het totale aantal ligt binnen het bereik dat u opgeeft (inclusief)."
);

$L["generate"] = "Genereren";
$L["help"] = "Deze optie genereert een willekeurig aantal woorden - het totale aantal ligt binnen het bereik dat u opgeeft (inclusief). Net als bij de Vast Aantal Woorden type, worden de woorden uit de Latijnse tekst Lorem ipsum gehaald.";
$L["incomplete_fields"] = "Voer de minimum en maximum aantal woorden in dat u wilt genereren. Zie rijen:";
$L["start_with_lipsum"] = "Begin met \"Lorem Ipsum...\"";
$L["to"] = "tot";
$L["words"] = "woorden";
