<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Email",
    "DESC" => "Génère une adresse e-mail aléatoire ."
);
