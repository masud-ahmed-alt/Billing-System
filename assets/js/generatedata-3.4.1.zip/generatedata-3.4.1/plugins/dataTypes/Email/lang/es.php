<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Correo electrónico",
    "DESC" => "Genera una dirección de correo electrónico al azar ."
);

