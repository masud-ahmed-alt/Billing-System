<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "E-mail",
    "DESC" => "Erzeugt eine zufällige E-Mail Adresse ."
);
