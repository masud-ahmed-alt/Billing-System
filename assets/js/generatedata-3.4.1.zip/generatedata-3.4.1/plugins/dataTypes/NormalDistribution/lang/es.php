<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Distribución normal",
    "DESC" => "Genera valores normalmente distribuidos al azar con una desviación media y estándar adaptable ."
);

$L["mean"] = "Media";
$L["standard_deviation"] = "Desviación estándar";
$L{"precision"} = "Precisión";
$L["incomplete_fields"] = "Los campos Media y Sigma son obligatorios para todas las filas de Distribución normal. Por favor, corrija las siguientes filas:";
