<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Erzeugt eine Zufallskreditkarte PIN-Nummer von 1111 bis 9999."
);
