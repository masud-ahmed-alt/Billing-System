<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Namen",
    "DESC" => "Dieser Datentyp zufällig generiert menschlichen Namen (meist Western) nach dem Format, das Sie angeben."
);

// Category: Lang Strings
$L["example_FemaleName"] = "Jane (Female Name)";
$L["example_FemaleName_Surname"] = "Jane Smith";
$L["example_MaleName"] = "John (männlich Name)";
$L["example_MaleName_Surname"] = "John Smith";
$L["example_Name"] = "Alex (geschlechtsspezifische)";
$L["example_Name4"] = "Jenny, Toby, Ben, Peter";
$L["example_Name_Initial_Surname"] = "Alex J. Smith";
$L["example_Name_Surname"] = "Alex Smith";
$L["example_Surname_Name_Initial"] = "Smith, John P.";
$L["example_fullnames"] = "Alex Smith oder Alex J. Smith";
$L["example_surname"] = "Smith (Familienname)";
$L["help_intro"] = "Zeichen (|) können Sie mehrere Formate, indem Sie sie mit dem Rohr geben. Die folgenden Zeichenfolgen werden auf die zufälligen Namen umgerechnet werden:";
$L["incomplete_fields"] = "Der Name Datentyp haben muss das Format eingetragen im Options Textfeld. Bitte beheben Sie die folgenden Zeilen:";
$L["name"] = "Name";
$L["type_FemaleName"] = "Ein weiblicher Vorname.";
$L["type_Initial"] = "Ein Großbuchstaben, AZ.";
$L["type_MaleName"] = "Ein männlicher Vorname.";
$L["type_Name"] = "Ein Vorname, männlich oder weiblich.";
$L["type_Surname"] = "Eine zufällige Nachnamen.";
