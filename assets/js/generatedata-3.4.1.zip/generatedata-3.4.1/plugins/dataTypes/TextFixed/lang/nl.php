<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Vast Aantal Woorden",
    "DESC" => "Deze optie genereert een vast aantal willekeurige woorden, die uit de standaard Latijnse tekst Lorem ipsum worden gehaald."
);

$L["TextFixed_generate"] = "Genereer";
$L["TextFixed_help"] = "Deze optie genereert een vast aantal willekeurige woorden, die uit de standaard Latijnse tekst <a href=\"http://en.wikipedia.org/wiki/Lorem_ipsum\" target=\"_blank\">Lorem ipsum</a> worden gehaald.";
$L["TextFixed_words"] = "woorden";
$L["incomplete_fields"] = "Vul het aantal woorden in dat u wilt genereren voor alle Vast Aantal Woorden velden. Zie rijen:";
