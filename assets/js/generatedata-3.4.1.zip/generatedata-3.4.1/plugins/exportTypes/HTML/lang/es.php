<?php

$L = array();
$L["data_format"] = "Formato de datos";
$L["custom_html_format"] = "Formato HTML personalizado";
$L["use_custom_html_format"] = "Usar formato HTML personalizado";
$L["batch_vars"] = "Indica si el lote actual de resultados que será generado será el primero o el último. Esto sólo se usa para datos generado en la misma página, lo que genera los resultados por lotes. En el resto de situaciones, ambos son verdaderos.";
$L["col_names_array"] = "Un array ordenado de cadenas conteniendo los nombres de columnas.";
$L["row_data_array"] = "Un array ordenado de arrays. Cada array de nivel superior almacena los contenidos de la fila; cada array hijo contiene un array ordenado de valores para cada ítem de datos.";
$L["available_smarty_vars"] = "Variables Smarty disponibles";
$L["reset_custom_html"] = "Restablecer HTML personalizado";
