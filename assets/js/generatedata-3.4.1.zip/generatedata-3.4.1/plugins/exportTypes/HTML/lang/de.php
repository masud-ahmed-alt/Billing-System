<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "HTML";

$L["data_format"] = "Datenformat";
$L["custom_html_format"] = "Custom HTML-Format";
$L["available_smarty_vars"] = "Verfügbare Smarty Vars";
$L["batch_vars"] = "Boolsche ob die aktuelle Charge der Ergebnisse erzeugt ist die erste oder letzte. Dies wird immer nur für Benutzer Erzeugen der Daten in-Seite, die die Ergebnisse in Blöcken generiert verwendet. In allen anderen Situationen, beide sind immer wahr.";
$L["col_names_array"] = "Ein geordnetes Array von Strings mit den Spaltennamen.";
$L["reset_custom_html"] = "Zurücksetzen Custom HTML";
$L["row_data_array"] = "Ein geordnetes Array von Arrays. Jeder Top-Level-Array enthält den Inhalt der Zeile, jedes Kind Array enthält eine geordnete Array von Werten für jedes Element von Daten.";
$L["use_custom_html_format"] = "Verwenden Sie benutzerdefinierte HTML-Format";