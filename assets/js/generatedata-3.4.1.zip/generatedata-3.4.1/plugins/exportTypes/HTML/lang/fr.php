<?php

$L = array();
$L["data_format"] = "Format des données";
$L["custom_html_format"] = "Format HTML personnalisé";

// Category: HTML
$L["available_smarty_vars"] = "Variables Smarty disponibles";
$L["batch_vars"] = "Booléen permettant de savoir si le lot courant des résultats générés est le premier ou le dernier. N'est utilisé que dans le cas d'une génération des données dans la page, ce qui génère des résultats en morceaux. Pour tous les autres cas, les deux valeurs sont toujours vrai.";
$L["col_names_array"] = "Tableau de chaînes contenant les noms de colonnes.";
$L["reset_custom_html"] = "Réinitialiser le HTML personnalisé";
$L["row_data_array"] = "Tableau ordonné des lignes. Chaque tableau parent contient le contenu de la ligne et chaque tableau enfant contient un tableau de valeurs correspondant aux colonnes. Voir l'exemple pour plus d'informations.";
$L["use_custom_html_format"] = "Utiliser un format HTML personnalisé";
