<?php

$L = array();

$L["available_smarty_vars"] = "Beschikbare Smarty variabelen";
$L["batch_vars"] = "Booleans om aan te geven of de huidige export batch de eerste of de laatste is. Dit wordt alleen gebruikt bij data die in-page wordt gegenereerd, waarbij de resultaten in blokken worden genereerd. In alle andere gevallen is deze waarde altijd waar.";
$L["col_names_array"] = "Een geordende array van tekenreeksen die de kolomnamen bevatten.";
$L["custom_html_format"] = "Aangepaste HTML-indeling";
$L["data_format"] = "Data Formaat";
$L["reset_custom_html"] = "Reset Aangepaste HTML";
$L["row_data_array"] = "Een geordende array van arrays. Elke topniveau array bevat de inhoud van de rij; elk gerelateerde array bevat een geordende array van waarden voor alle gegeven.";
$L["use_custom_html_format"] = "Gebruik aangepast HTML-formaat";