<?php

$L = array();

$L["available_smarty_vars"] = "Beschikbare Smarty Variabelen";
$L["batch_vars"] = "Booleans om aan te geven of de huidige batch van resultaten die worden gegenereerd de eerste of de laatste is. Dit wordt alleen gebruikt voor type in-page, waarvoor de resultaten in blokken worden genereerd. In alle andere gevallen is de waarde waar.";
$L["col_names_array"] = "Een geordende array van tekenreeksen die de kolomnamen.";
$L["invalid_node_names"] = "XML-node namen kunnen mogen alleen bestaan uit alfanumerieke tekens en moeten beginnen met een letter. Pas de volgende rij(en) aan:";
$L["invalid_xml_record_node_name"] = "Geef een geldige waarde op voor de XML record node naam.";
$L["invalid_xml_root_node_name"] = "Geef een geldige waarde op voor de XML root node naam.";
$L["missing_xml_record_node_name"] = "Gelieve een waarde voor de XML record node naam.";
$L["missing_xml_root_node_name"] = "Gelieve een waarde voor de XML root node naam.";
$L["record_node_name"] = "Record nodenaam";
$L["reset_custom_html"] = "Reset Aangepaste HTML";
$L["root_node_name"] = "Root node naam";
$L["row_data_array"] = "Een geordende array van arrays. Elke topniveau array bevat de inhoud van de rij; elk gerelateerde array bevat een geordende array van waarden voor alle gegeven.";
$L["row_label"] = "Node naam";
$L["row_label_plural"] = "Node Namen";
$L["use_custom_xml_format"] = "Aangepast XML-formaat";
