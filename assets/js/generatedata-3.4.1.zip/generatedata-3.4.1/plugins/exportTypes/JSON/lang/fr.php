<?php

$L = array();

// Category: JSON
$L["complex"] = "Complexe";
$L["data_structure_format"] = "Format de la structure des données";
$L["simple"] = "Simple";
$L["strip_whitespace"] = "Enlever les espaces dans les résultats générés";
