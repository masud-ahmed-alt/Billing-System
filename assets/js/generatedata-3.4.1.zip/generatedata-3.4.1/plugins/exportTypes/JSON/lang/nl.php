<?php

$L = array();
$L["complex"] = "Complex";
$L["data_structure_format"] = "Datastructuur format";
$L["simple"] = "Eenvoudig";
$L["strip_whitespace"] = "Verwijder spaties in de gegenereerde resultaten";
