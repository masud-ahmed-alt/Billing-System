<?php

$L = array();
$L["strip_whitespace"] = "Strip whitespace from generated results";
$L["complex"] = "Complex";
$L["simple"] = "Simple";
$L["data_structure_format"] = "Data structure format";