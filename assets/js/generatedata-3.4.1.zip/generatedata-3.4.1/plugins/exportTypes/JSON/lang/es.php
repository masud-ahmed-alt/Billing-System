<?php

$L = array();
$L["strip_whitespace"] = "Eliminar espacios en blanco de los resultados generados";
$L["complex"] = "Complejo";
$L["simple"] = "Simple";
$L["data_structure_format"] = "Formato de estructura de datos";
