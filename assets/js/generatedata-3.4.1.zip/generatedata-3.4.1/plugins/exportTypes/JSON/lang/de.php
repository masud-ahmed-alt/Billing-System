<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "JSON";

$L["complex"] = "Komplex";
$L["data_structure_format"] = "Datenstruktur-Format";
$L["simple"] = "Einfach";
$L["strip_whitespace"] = "Isolieren Sie Leerzeichen aus generierten Ergebnisse";
