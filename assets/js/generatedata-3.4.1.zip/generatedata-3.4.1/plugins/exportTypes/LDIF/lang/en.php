<?php

$L = array();