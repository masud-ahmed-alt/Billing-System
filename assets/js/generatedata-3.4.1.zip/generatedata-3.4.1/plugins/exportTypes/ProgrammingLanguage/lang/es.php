<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "Lenguaje de programación";
$L["row_label"] = "Nombre de var/prop";
$L["language"] = "Lenguaje";
