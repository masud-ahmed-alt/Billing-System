<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "Langage de Programmation";
$L["row_label"] = "Nom de la variable ou de la propriété";
$L["language"] = "Langage";