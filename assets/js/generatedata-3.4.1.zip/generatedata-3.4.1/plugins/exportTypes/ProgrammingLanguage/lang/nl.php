<?php

$L = array();

$L["EXPORT_TYPE_NAME"] = "Programmeertaal";
$L["language"] = "Taal";
$L["row_label"] = "Variabele / Optie Naam";