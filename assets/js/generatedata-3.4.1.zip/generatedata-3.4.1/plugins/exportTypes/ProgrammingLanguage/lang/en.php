<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "Programming Language";
$L["row_label"] = "Var/Prop Name";
$L["language"] = "Language";