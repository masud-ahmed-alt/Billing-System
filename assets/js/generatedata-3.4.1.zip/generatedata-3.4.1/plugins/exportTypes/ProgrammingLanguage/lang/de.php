<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "Programmiersprache";
$L["row_label"] = "Var/Prop Name";
$L["language"] = "Sprache";