<?php

$L = array();
$L["row_label"] = "Columna de la tabla";
$L["row_label_plural"] = "Columnas de la tabla";
$L["validation_invalid_col_name"] = "Por favor, introduce nombres válidos de columnas de la base de datos para cada fila (a-Z y guión bajo). Por favor, corrige las siguientes filas:";
$L["validation_invalid_table_name"] = "Por favor, introduce un nombre válido de tabla de base de datos (a-Z y guión bajo).";
$L["validation_invalid_batch_size"] = "Por favor introduce el tamaño del lote válido (1-300)";

$L["db_table_name"] = "Nombre de tabla";
$L["db_type"] = "Tipo de base de datos";
$L["misc_options"] = "Opciones varias";
$L["include_create_table_query"] = "Incluir sentencia CREATE TABLE";
$L["include_drop_table_query"] = "Incluir sentencia DROP TABLE";
$L["enclose_table_backquotes"] = "Entrecomillar nombres (tablas, columnas)";
$L["statement_type"] = "Tipo de sentencia";
$L["primary_key"] = "Clave primaria";
$L["add_default_auto_increment_col"] = "Añadir columna auto-incrementada por defecto";
$L["insert_batch_size"] = "INSERT tamaño de lote";
$L["batch_size_desc"] = "Número de filas a insertar por una consulta (1-300)";