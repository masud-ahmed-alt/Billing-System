<?php


$L = array();

// Category: Lang Strings
$L["add_default_auto_increment_col"] = "Ajouter une colonne d'auto-incrémentation";
$L["db_table_name"] = "Nom de la table";
$L["db_type"] = "Type de base de données";
$L["enclose_table_backquotes"] = "Protéger les noms des tables et des champs avec des `backquotes`";
$L["include_create_table_query"] = "Inclure une requête CREATE TABLE";
$L["include_drop_table_query"] = "Inclure une requête DROP TABLE";
$L["misc_options"] = "Options diverses";
$L["primary_key"] = "Clé primaire";
$L["row_label"] = "Colonne";
$L["row_label_plural"] = "Colonnes";
$L["statement_type"] = "Type de requêtes";
$L["validation_invalid_col_name"] = "Entrez des noms valides pours les noms de colonnes pour chaque ligne (aZ et _). Corrigez les lignes suivantes:";
$L["validation_invalid_table_name"] = "Entrer un nom de table de base de données valide (aZ et _).";
$L["validation_invalid_batch_size"] = "S'il vous plaît entrez la taille du lot valide (1 - 300)";
$L["insert_batch_size"] = "INSERT la taille du lot";
$L["batch_size_desc"] = "Nombre de lignes à insérer par une requête (1 - 300)";