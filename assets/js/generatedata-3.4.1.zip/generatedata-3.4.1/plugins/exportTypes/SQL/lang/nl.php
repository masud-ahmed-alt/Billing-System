<?php

$L = array();

$L["add_default_auto_increment_col"] = "Voeg standaard auto-increment kolom toe";
$L["db_table_name"] = "Database tabelnaam";
$L["db_type"] = "Database Type";
$L["enclose_table_backquotes"] = "Omsluit tabel-en veldnamen met aanhalingstekens";
$L["include_create_table_query"] = "Inclusief CREATE TABLE statement";
$L["include_drop_table_query"] = "Inclusief DROP TABLE statement";
$L["misc_options"] = "Overige Opties";
$L["primary_key"] = "Primaire sleutel";
$L["row_label"] = "Tabelkolom";
$L["row_label_plural"] = "Tabel Kolommen";
$L["statement_type"] = "Statement Type";
$L["validation_invalid_col_name"] = "Geef een geldige databank kolomnaam in voor elke rij (aZ en onderstrepingstekens). Pas de volgende rij(en) aan:";
$L["validation_invalid_table_name"] = "Geef een geldige database tabel naam (az en onderstrepingstekens alleen) in.";
$L["validation_invalid_batch_size"] = "Geef een geldige seriegrootte (1-300)";
$L["insert_batch_size"] = "INSERT batch grootte";
$L["batch_size_desc"] = "Aantal rijen uit te voegen per query (1-300)";