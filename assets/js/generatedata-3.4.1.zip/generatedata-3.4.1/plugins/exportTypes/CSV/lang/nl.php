<?php

$L = array();

$L["delimiter_chars"] = "Scheidingsteken";
$L["eol_char"] = "Einde van de lijn karakter";
$L["validation_no_delimiter"] = "Geef een scheidingsteken voor het CSV export type.";
