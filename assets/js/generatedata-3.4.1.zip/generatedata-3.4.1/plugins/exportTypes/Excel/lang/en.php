<?php

$L = array();
